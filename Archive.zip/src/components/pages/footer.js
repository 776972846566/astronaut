import React, { Component } from 'react';
import social1  from '../images/social1.png';
import social5  from '../images/social5.png';

class Footer extends Component {
  render() {
	 return (
		 <div>
			 
		 </div>

    );
  }
}

export default Footer;