import React, { Component } from 'react';

import $ from "jquery";
import Header from '../../pages/header.js';
import Footer from '../../pages/footer.js';

import bnrcharacter from '../../images/bnrcharacter.png';
import telegram from '../../images/telegram.png';

import socialcharacter from '../../images/socialcharacter.png';
import twitter from '../../images/twitter.png';
import Subtraction from '../../images/Subtraction.png';
import Layer from '../../images/Layer.png';

import arrowright from '../../images/arrowright.png';
import arrowleft from '../../images/arrowleft.png';
import heart from '../../images/heart.png';
import icon333 from '../../images/icon333.png';

import metalchild from '../../images/metalchild1.png';

import Maskimg from '../../images/Maskimg.png';
import mo1 from '../../images/mo1.png';
import mo4 from '../../images/mo4.png';
import mo5 from '../../images/mo5.png';
import mo6 from '../../images/mo6.png';
import mo7 from '../../images/mo7.png';
import mo8 from '../../images/mo8.png';





class Home extends Component {
	constructor(props) {
		super(props);
		this.state = {
		};

	}

	componentDidMount = () => {



	}

	render() {
		return (
			<div>
				<div className="bnr-bg">
					<Header />

					<div className='bnr-main-wrap'>
						<div className='container'>
							<div className='row'>
								<div className='col-lg-2'>

								</div>
								<div className='col-lg-5'>
									<div className='bnr-cont'>
										<h3>Welcome to</h3>
										<h1>MERLIN</h1>
										<p>You’re a MERLIN now the possibilities are endless.</p>
										<div className='bnr-but-wrap'>
											<div className='buy-marlin-but'>
												<a href='#'>BUY MERLIN</a>
											</div>
											<div className='buy-nft-but'>
												<a href='#'>Buy nft</a>
											</div>
										</div>
									</div>

								</div>
								<div className='col-lg-5'>
									<div className='bnr-img'>
										<img src={bnrcharacter}></img>
									</div>
								</div>
							</div>

						</div>
					</div>
					<div className='copy-icon-wrp'>
						<div className='copy-text'>
							<p>© 2022 Marlin. All rights reserved.</p>
						</div>
						<div className='icon-ing'>
							<div className='icon-child1'>
								<a href='#'><img src={Subtraction}></img></a>
							</div>
							<div className='icon-child1'>
								<a href='#'><img src={telegram}></img></a>
							</div>
							<div className='icon-child1'>
								<a href='#'><img src={twitter}></img></a>
							</div>
							<div className='icon-child1'>
								<a href='#'><img src={socialcharacter}></img></a>
							</div>
						</div>
					</div>
				</div>
				<div className='bnr-bg1'>
					<div className='bnr-child-bg1'>
						<div className='layer-img'>
							<img src={Layer}></img>
						</div>
						<div className='benefits-text'>
							<h3>JOIN OUR<br></br>BENEFITS</h3>
							<p>Lorem ipsum dolor sit amet, consetetur sadipscing<br></br>
								elitr, sed diam nonumy eirmod tempor invidunt ut<br></br>
								labore et dolore magna aliquyam erat, sed diam<br></br>
								voluptua. At vero eos et accusam et justo duo dolores<br></br>
								et ea rebum. Stet clita kasd gubergren, no sea<br></br>
								takimata sanctus estemated.</p>
							<h2>WHITEPAPER</h2>

						</div>

					</div>
				</div>
				<div className='our-future-bg'>
					<div className='our-future-wrapbg'>
						<div className='our-future-child'>
							<h3>OUR</h3>
						</div>
						<div className='our-future-text11'>
							<p>Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt<br></br>
								ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et<br></br>
								ea rebum. Stet clita kasd gubergren, no sea takimata sanctus estemated.</p>
						</div>
						<div className='our-future-child-flex'>
							<div className='our-future-child1'>
								<div className='our-future-child1-flex'>
									<h2>Q1</h2>
									<p>2022</p>
								</div>
								<div className='our-future-websitebg1'>
									<p>Launch website</p>
								</div>
								<div className='our-future-websitebg1'>
									<p>Launch website</p>
								</div>
								<div className='our-future-websitebg1'>
									<p>Launch website</p>
								</div>
								<div className='our-future-websitebg1'>
									<p>Launch website</p>
								</div>
								<div className='our-future-websitebg1'>
									<p>Launch website</p>
								</div>
								<div className='our-future-websitebg1'>
									<p>Launch website</p>
								</div>

							</div>

							<div className='our-future-child2'>
								<div className='our-future-child1-flex'>
									<h2>Q2</h2>
									<p>2022</p>
								</div>
								<div className='our-future-websitebg1'>
									<p>Launch website</p>
								</div>
								<div className='our-future-websitebg1'>
									<p>Launch website</p>
								</div>
								<div className='our-future-websitebg1'>
									<p>Launch website</p>
								</div>
								<div className='our-future-websitebg1'>
									<p>Launch website</p>
								</div>
								<div className='our-future-websitebg1'>
									<p>Launch website</p>
								</div>
								<div className='our-future-websitebg1'>
									<p>Launch website</p>
								</div>
							</div>
						</div>


						<div className='our-future-textarrow'>
							<div className='our-future-text'>
								<h2>WHITEPAPER</h2>
							</div>
							<div className='arrow-img'>
								<a href='#'><img src={arrowright}></img></a>
								<a href='#'><img src={arrowleft}></img></a>
							</div>

						</div>
					</div>
				</div>
				<div className='nftmarketplace-bg'>
					<div className='container'>
						<div className='nftmarketplace-child1'>
							<div className='stakenft-text'>
								<h3>NFT MARKETPLACE</h3>
							</div>

							<div className='create-nftbg'>
								<a href='#'><p className='createbtn-nftbtn'>CREATE NFT</p></a>
							</div>

						</div>
						<div className='create-nft-text'>
							<p>Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt
								ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et
								ea rebum. Stet clita kasd gubergren, no sea takimata sanctus estemated.</p>

						</div>
						<div className="header-create-nft">
							<header>

								<nav class="navbar navbar-expand-lg navbar-dark pink scrolling-navbar">

									<div class="collapse navbar-collapse" id="navbarSupportedContent">
										<ul class="navbar-nav">
											<li class="nav-item">
												<a class="navbar-brand" href="#"><b>Auction</b></a>
											</li>
											<li class="nav-item active">
												<a class="nav-link" href="#">Fixd Price Sale<span class="sr-only">(current)</span></a>
											</li>
											<li class="nav-item">
												<a class="nav-link" href="#">Sold Out / Expired</a>
											</li>
											<li class="nav-item">
												<a class="nav-link" href="#">My Bids</a>
											</li>
											<li class="nav-item">
												<a class="nav-link" href="#">Your NFTs</a>
											</li>
											<li>
												<a class="nav-link" href="#">Your NFTs</a>
											</li>
											<li>
												<a class="nav-link" href="#">Imported NFTs</a>
											</li>
										</ul>
										<div className='navbar-left1'>
											<ul class="navbar-nav">
												<li>
													<a class="nav-link" href="#">SHOW ALL</a>
												</li>

												<li class="nav-item">

													<div className='leftrightarrow'>
														<a href='#'><img src={arrowright}></img></a>
														<a href='#'><img className='left-arrow22' src={arrowleft}></img></a>
													</div>
												</li>
											</ul>
										</div>

									</div>
								</nav>

							</header>
						</div>
						<div className='metalmorphosis-body'>
							<div className='metalmorphosis-bg'>
								<div className='metalmorphosis-img'>
									<div className='metalmorphosis-childimg'>
										<div className='metalmorphosis-childtextbg'>

											<div className='metalmorphosis-child1'>
												<div className='metalmorphosis-childtext'>
													<a href='#'><img src={heart}></img> 231</a>
													<p>100 BUSD</p>
												</div>
												<h3>METAL MORPHOSIS</h3>
												<div className='metalmorphosis-child1text'>
													<div className='metalmorphosis-p'>
														<p>Highest Bid</p>
														<p>Your Bid</p>
														<p>Ends In</p>
													</div>
													<div className='metalmorphosis-p'>
														<p>100.00 BUSD</p>
														<p>0.00 BUSD</p>
														<p>28d:19h:17m</p>
													</div>
												</div>
											</div>
										</div>
									</div>
								</div>
							</div>

							<div className='metalmorphosis-bg'>
								<div className='metalmorphosis-img'>
									<div className='metalmorphosis-childimg'>
										<div className='metalmorphosis-childtextbg'>

											<div className='metalmorphosis-child1'>
												<div className='metalmorphosis-childtext'>
													<a href='#'><img src={heart}></img> 231</a>
													<p>100 BUSD</p>
												</div>
												<h3>METAL MORPHOSIS</h3>
												<div className='metalmorphosis-child1text'>
													<div className='metalmorphosis-p'>
														<p>Highest Bid</p>
														<p>Your Bid</p>
														<p>Ends In</p>
													</div>
													<div className='metalmorphosis-p'>
														<p>100.00 BUSD</p>
														<p>0.00 BUSD</p>
														<p>28d:19h:17m</p>
													</div>
												</div>
											</div>
										</div>
									</div>
								</div>
							</div>

							<div className='metalmorphosis-bg'>
								<div className='metalmorphosis-img'>
									<div className='metalmorphosis-childimg'>
										<div className='metalmorphosis-childtextbg'>

											<div className='metalmorphosis-child1'>
												<div className='metalmorphosis-childtext'>
													<a href='#'><img src={heart}></img> 231</a>
													<p>100 BUSD</p>
												</div>
												<h3>METAL MORPHOSIS</h3>
												<div className='metalmorphosis-child1text'>
													<div className='metalmorphosis-p'>
														<p>Highest Bid</p>
														<p>Your Bid</p>
														<p>Ends In</p>
													</div>
													<div className='metalmorphosis-p'>
														<p>100.00 BUSD</p>
														<p>0.00 BUSD</p>
														<p>28d:19h:17m</p>
													</div>
												</div>
											</div>
										</div>
									</div>
								</div>
							</div>

							<div className='metalmorphosis-bg'>
								<div className='metalmorphosis-img'>
									<div className='metalmorphosis-childimg'>
										<div className='metalmorphosis-childtextbg'>

											<div className='metalmorphosis-child1'>
												<div className='metalmorphosis-childtext'>
													<a href='#'><img src={heart}></img> 231</a>
													<p>100 BUSD</p>
												</div>
												<h3>METAL MORPHOSIS</h3>
												<div className='metalmorphosis-child1text'>
													<div className='metalmorphosis-p'>
														<p>Highest Bid</p>
														<p>Your Bid</p>
														<p>Ends In</p>
													</div>
													<div className='metalmorphosis-p'>
														<p>100.00 BUSD</p>
														<p>0.00 BUSD</p>
														<p>28d:19h:17m</p>
													</div>
												</div>
											</div>
										</div>
									</div>
								</div>
							</div>
						</div>
						<div className='our-future-textarrow'>
							<div className='our-future-text1'>
								<h2>WHITEPAPER</h2>
							</div>
						</div>

					</div>
				</div>
				<div className='stakenft-bg'>
					<div className='stakenft-child1'>
						<div className='container'>
							<div className='nftmarketplace-child1'>
								<div className='stakenft-text'>
									<h3>STAKE NFT</h3>
								</div>

								<div className='create-nftbg'>
									<a href='#'><p className='createbtn-nftbtn'>CREATE NFT</p></a>
								</div>

							</div>
							<div className='create-nft-text'>
								<p>Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt
									ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et
									ea rebum. Stet clita kasd gubergren, no sea takimata sanctus estemated.</p>

							</div>
							<div className="header-create-nft">
								<header>

									<nav class="navbar navbar-expand-lg navbar-dark pink scrolling-navbar">

										<div class="collapse navbar-collapse" id="navbarSupportedContent">
											<ul class="navbar-nav">
												<li class="nav-item">
													<a class="navbar-brand" href="#"><b>Auction</b></a>
												</li>
												<li class="nav-item active">
													<a class="nav-link" href="#">inactive<span class="sr-only">(current)</span></a>
												</li>

											</ul>
											<div className='navbar-left2'>
												<ul class="navbar-nav">
													<li>
														<a class="nav-link" href="#">SHOW ALL</a>
													</li>

													<li class="nav-item">

														<div className='leftrightarrow'>
															<a href='#'><img src={arrowright}></img></a>
															<a href='#'><img className='left-arrow22' src={arrowleft}></img></a>
														</div>
													</li>
												</ul>
											</div>

										</div>
									</nav>

								</header>
							</div>
							<div className='stakenft-child2'>
								<div className='stakenft-text1'>
									<h3>EARN NFT</h3>
								</div>

							</div>
							<div className='oarcanenft-img'>
								<div class="container">
									<div class="row">
										<div class="col-lg-4">
											<div className='oarcanenft-child'>
												<div className='oarcanenft-childimg'>
													<img src={icon333}></img>
												</div>
												<div className='arcanenft-text'>
													<h3>O ARCANE NFT</h3>
												</div>
											</div>
										</div>
										<div class="col-lg-5">
											<div className='oarcanenft-child1'>
												<div className='arcanenft-text1'>
													<h3>O ARCANE</h3>
												</div>
												<div className='arcanenft-text1'>
													<h3>REDEEMABLE</h3>
												</div>

											</div>
										</div>
										<div class="col-lg-3">
											<div className='oarcanenft-child2'>
												<div className='arcanenft-text1'>
													<h3>NA</h3>
												</div>
												<div className='arcanenft-textbtn'>
													<a href='#'><p className='create-nftbtn'>STAKE</p></a>
												</div>
											</div>

										</div>
									</div>
								</div>
							</div>

							<div className='oarcanenft-img'>
								<div class="container">
									<div class="row">
										<div class="col-lg-4">
											<div className='oarcanenft-child'>
												<div className='oarcanenft-childimg'>
													<img src={icon333}></img>
												</div>
												<div className='arcanenft-text'>
													<h3>O ARCANE NFT</h3>
												</div>
											</div>
										</div>
										<div class="col-lg-5">
											<div className='oarcanenft-child1'>
												<div className='arcanenft-text1'>
													<h3>O ARCANE</h3>
												</div>
												<div className='arcanenft-text1'>
													<h3>REDEEMABLE</h3>
												</div>

											</div>
										</div>
										<div class="col-lg-3">
											<div className='oarcanenft-child2'>
												<div className='arcanenft-text1'>
													<h3>NA</h3>
												</div>
												<div className='arcanenft-textbtn'>
													<a href='#'><p className='create-nftbtn'>STAKE</p></a>
												</div>
											</div>

										</div>
									</div>
								</div>
							</div>

							<div className='oarcanenft-img'>
								<div class="container">
									<div class="row">
										<div class="col-lg-4">
											<div className='oarcanenft-child'>
												<div className='oarcanenft-childimg'>
													<img src={icon333}></img>
												</div>
												<div className='arcanenft-text'>
													<h3>O ARCANE NFT</h3>
												</div>
											</div>
										</div>
										<div class="col-lg-5">
											<div className='oarcanenft-child1'>
												<div className='arcanenft-text1'>
													<h3>O ARCANE</h3>
												</div>
												<div className='arcanenft-text1'>
													<h3>REDEEMABLE</h3>
												</div>

											</div>
										</div>
										<div class="col-lg-3">
											<div className='oarcanenft-child2'>
												<div className='arcanenft-text1'>
													<h3>NA</h3>
												</div>
												<div className='arcanenft-textbtn'>
													<a href='#'><p className='create-nftbtn'>STAKE</p></a>
												</div>
											</div>

										</div>
									</div>
								</div>
							</div>

							<div className='oarcanenft-img'>
								<div class="container">
									<div class="row">
										<div class="col-lg-4">
											<div className='oarcanenft-child'>
												<div className='oarcanenft-childimg'>
													<img src={icon333}></img>
												</div>
												<div className='arcanenft-text'>
													<h3>O ARCANE NFT</h3>
												</div>
											</div>
										</div>
										<div class="col-lg-5">
											<div className='oarcanenft-child1'>
												<div className='arcanenft-text1'>
													<h3>O ARCANE</h3>
												</div>
												<div className='arcanenft-text1'>
													<h3>REDEEMABLE</h3>
												</div>

											</div>
										</div>
										<div class="col-lg-3">
											<div className='oarcanenft-child2'>
												<div className='arcanenft-text1'>
													<h3>NA</h3>
												</div>
												<div className='arcanenft-textbtn'>
													<a href='#'><p className='create-nftbtn'>STAKE</p></a>
												</div>
											</div>

										</div>
									</div>
								</div>
							</div>
						</div>
					</div>

				</div>
				<div className='nftmarketplece-bg-img'>
					<div className='container'>
						<div className='nftmarketplace-child1'>
							<div className='stakenft-text'>
								<h3>NFT MARKETPLACE</h3>
							</div>

							<div className='create-nftbg'>
								<a href='#'><p className='createbtn-nftbtn'>CREATE NFT</p></a>
							</div>
						</div>
						<div className='nftmarketplace-child2'>
							<div className='nftmarketplace-child2-textarrow'>
								<div className='our-future-text'>
									<h2>TOP PICKS</h2>
								</div>
								<div className='arrow-img1'>
									<a class="nav1-link" href="#">SHOW ALL</a>
									<a href='#'><img src={arrowright}></img></a>
									<a href='#'><img src={arrowleft}></img></a>
								</div>

							</div>
						</div>
						<div className='metalmorphosis-body'>
							<div className='metalmorphosis-bg'>
								<div className='metalmorphosis-img'>
									<div className='metalmorphosis-childimg'>
										<div className='metalmorphosis-childtextbg'>

											<div className='metalmorphosis-child1'>
												<div className='metalmorphosis-childtext'>
													<a href='#'><img src={heart}></img> 231</a>
													<p>100 BUSD</p>
												</div>
												<h3>METAL MORPHOSIS</h3>
												<div className='metalmorphosis-child1text'>
													<div className='metalmorphosis-p'>
														<p>Highest Bid</p>
														<p>Your Bid</p>
														<p>Ends In</p>
													</div>
													<div className='metalmorphosis-p'>
														<p>100.00 BUSD</p>
														<p>0.00 BUSD</p>
														<p>28d:19h:17m</p>
													</div>
												</div>
											</div>
										</div>
									</div>
								</div>
							</div>

							<div className='metalmorphosis-bg'>
								<div className='metalmorphosis-img'>
									<div className='metalmorphosis-childimg'>
										<div className='metalmorphosis-childtextbg'>

											<div className='metalmorphosis-child1'>
												<div className='metalmorphosis-childtext'>
													<a href='#'><img src={heart}></img> 231</a>
													<p>100 BUSD</p>
												</div>
												<h3>METAL MORPHOSIS</h3>
												<div className='metalmorphosis-child1text'>
													<div className='metalmorphosis-p'>
														<p>Highest Bid</p>
														<p>Your Bid</p>
														<p>Ends In</p>
													</div>
													<div className='metalmorphosis-p'>
														<p>100.00 BUSD</p>
														<p>0.00 BUSD</p>
														<p>28d:19h:17m</p>
													</div>
												</div>
											</div>
										</div>
									</div>
								</div>
							</div>
							<div className='metalmorphosis-bg'>
								<div className='metalmorphosis-img'>
									<div className='metalmorphosis-childimg'>
										<div className='metalmorphosis-childtextbg'>

											<div className='metalmorphosis-child1'>
												<div className='metalmorphosis-childtext'>
													<a href='#'><img src={heart}></img> 231</a>
													<p>100 BUSD</p>
												</div>
												<h3>METAL MORPHOSIS</h3>
												<div className='metalmorphosis-child1text'>
													<div className='metalmorphosis-p'>
														<p>Highest Bid</p>
														<p>Your Bid</p>
														<p>Ends In</p>
													</div>
													<div className='metalmorphosis-p'>
														<p>100.00 BUSD</p>
														<p>0.00 BUSD</p>
														<p>28d:19h:17m</p>
													</div>
												</div>
											</div>
										</div>
									</div>
								</div>
							</div>
							<div className='metalmorphosis-bg'>
								<div className='metalmorphosis-img'>
									<div className='metalmorphosis-childimg'>
										<div className='metalmorphosis-childtextbg'>

											<div className='metalmorphosis-child1'>
												<div className='metalmorphosis-childtext'>
													<a href='#'><img src={heart}></img> 231</a>
													<p>100 BUSD</p>
												</div>
												<h3>METAL MORPHOSIS</h3>
												<div className='metalmorphosis-child1text'>
													<div className='metalmorphosis-p'>
														<p>Highest Bid</p>
														<p>Your Bid</p>
														<p>Ends In</p>
													</div>
													<div className='metalmorphosis-p'>
														<p>100.00 BUSD</p>
														<p>0.00 BUSD</p>
														<p>28d:19h:17m</p>
													</div>
												</div>
											</div>
										</div>
									</div>
								</div>
							</div>
						</div>
						<div className=''>
							<div className='featuredcollection-text'>
								<h3>FEATURED COLLECTIONS</h3>
							</div>
							<div className='featuredcollection-allbody'>
								<div className='featuredcollection-child1'>
									<div className='marlinofficial-img1'>
										<div className='marlinofficial-bodytext1'>
											<div className='collection-btn'>
												<a href='#'>COLLECTION</a>
											</div>
											<div className='MERLINofficil-text'>
												<h3>MERLIN official</h3>
												<p>Collection Wizard Officil Welcome to Arcane, a world of unique<br></br>
													experience and magic never before available on the blockchin.</p>
											</div>
											<div className='marlinofficial-btn-text'>
												<div className='viewitemonsale-btnflex'>
													<div className='viewitemonsale-img'>
														<a href='#'><p className='viewitemonsale-btn'>vIEW ITEM ON SALE</p></a>
													</div>
													<div>
														<a href='#'><p className='viewitemonsale-btn-text'>VISIT WEBSITE</p></a>
													</div>

												</div>
											</div>
										</div>

									</div>
								</div>
								<div className=''>
									<div className='featuredcollection-child2'>
										<div className='marlinofficial-img2'>
											<div className='marlinofficial-bodytext2'>
												<div className='collection-btn'>
													<a href='#'>COLLECTION</a>
												</div>
												<div className='MERLINofficil-text'>
													<h3>MERLIN official</h3>
												</div>
												<div className='marlinofficial-btn-text'>
													<div className='viewitemonsale-btnflex'>
														<div className='viewitemonsale-img'>
															<a href='#'><p className='viewitemonsale-btn'>vIEW ITEM ON SALE</p></a>
														</div>
														<div>
															<a href='#'><p className='viewitemonsale-btn-text'>VISIT WEBSITE</p></a>
														</div>

													</div>
												</div>
											</div>

										</div>
									</div>

									<div className='featuredcollection-child2'>
										<div className='marlinofficial-img3'>
											<div className='marlinofficial-bodytext2'>
												<div className='collection-btn'>
													<a href='#'>COLLECTION</a>
												</div>
												<div className='MERLINofficil-text'>
													<h3>MERLIN official</h3>
												</div>
												<div className='marlinofficial-btn-text'>
													<div className='viewitemonsale-btnflex'>
														<div className='viewitemonsale-img'>
															<a href='#'><p className='viewitemonsale-btn'>vIEW ITEM ON SALE</p></a>
														</div>
														<div>
															<a href='#'><p className='viewitemonsale-btn-text'>VISIT WEBSITE</p></a>
														</div>

													</div>
												</div>
											</div>

										</div>
									</div>

								</div>

							</div>
							<div className='featuredcollection-child3'>
								<div className='featuredcollection-imgbody'>
									<div className='featuredcollection-bannar-img'>
										<img src={mo4}></img>
									</div>
									<div className='featuredcollection-bannar-img'>
										<img src={mo5}></img>
									</div>
									<div className='featuredcollection-bannar-img'>
										<img src={mo6}></img>
									</div>
									<div className='featuredcollection-bannar-img'>
										<img src={mo7}></img>
									</div>
									<div className='featuredcollection-bannar-img'>
										<img src={mo8}></img>
									</div>

								</div>

							</div>


						</div>

						<div className='topweeklysellers'>
							<div className='featuredcollection-text'>
								<h3>TOP WEEKLY SELLERS</h3>
							</div>
							<div className='mask-ox-bodyflex'>
								<div className='mask-ox-flex'>
									<div className='mask-img'>
										<img src={Maskimg}></img>
									</div>
									<div className='ox-text-body'>
										<div className='ox-text'>
											<h3>OX1926....09AE47</h3>
											<p>$199999</p>
										</div>
									</div>
								</div>
								<div className='mask-ox-flex'>
									<div className='mask-img'>
										<img src={Maskimg}></img>
									</div>
									<div className='ox-text-body'>
										<div className='ox-text'>
											<h3>OX1926....09AE47</h3>
											<p>$199999</p>
										</div>
									</div>
								</div>
								<div className='mask-ox-flex'>
									<div className='mask-img'>
										<img src={Maskimg}></img>
									</div>
									<div className='ox-text-body'>
										<div className='ox-text'>
											<h3>OX1926....09AE47</h3>
											<p>$199999</p>
										</div>
									</div>
								</div>
								<div className='mask-ox-flex'>
									<div className='mask-img'>
										<img src={Maskimg}></img>
									</div>
									<div className='ox-text-body'>
										<div className='ox-text'>
											<h3>OX1926....09AE47</h3>
											<p>$199999</p>
										</div>
									</div>
								</div>

							</div>


							<div className="header-create-nft">
								<header>

									<nav class="navbar navbar-expand-lg navbar-dark pink scrolling-navbar">

										<div class="collapse navbar-collapse" id="navbarSupportedContent">
											<ul class="navbar-nav">
												<li class="nav-item">
													<a class="navbar-brand" href="#"><b>Auction</b></a>
												</li>
												<li class="nav-item active">
													<a class="nav-link" href="#">Fixd Price Sale<span class="sr-only">(current)</span></a>
												</li>
												<li class="nav-item">
													<a class="nav-link" href="#">Sold Out / Expired</a>
												</li>
												<li class="nav-item">
													<a class="nav-link" href="#">My Bids</a>
												</li>
												<li class="nav-item">
													<a class="nav-link" href="#">Your NFTs</a>
												</li>
												<li>
													<a class="nav-link" href="#">Your NFTs</a>
												</li>
												<li>
													<a class="nav-link" href="#">Imported NFTs</a>
												</li>
											</ul>
											<div className='navbar-left1'>
												<ul class="navbar-nav">
													<li>
														<a class="nav-link" href="#">SHOW ALL</a>
													</li>

													<li class="nav-item">

														<div className='leftrightarrow'>
															<a href='#'><img src={arrowright}></img></a>
															<a href='#'><img className='left-arrow22' src={arrowleft}></img></a>
														</div>
													</li>
												</ul>
											</div>

										</div>
									</nav>

								</header>
							</div>
							<div className='metalmorphosis-body'>
								<div className='metalmorphosis-bg'>
									<div className='metalmorphosis-img'>
										<div className='metalmorphosis-childimg'>
											<div className='metalmorphosis-childtextbg'>

												<div className='metalmorphosis-child1'>
													<div className='metalmorphosis-childtext'>
														<a href='#'><img src={heart}></img> 231</a>
														<p>100 BUSD</p>
													</div>
													<h3>METAL MORPHOSIS</h3>
													<div className='metalmorphosis-child1text'>
														<div className='metalmorphosis-p'>
															<p>Highest Bid</p>
															<p>Your Bid</p>
															<p>Ends In</p>
														</div>
														<div className='metalmorphosis-p'>
															<p>100.00 BUSD</p>
															<p>0.00 BUSD</p>
															<p>28d:19h:17m</p>
														</div>
													</div>
												</div>
											</div>
										</div>
									</div>
								</div>

								<div className='metalmorphosis-bg'>
									<div className='metalmorphosis-img'>
										<div className='metalmorphosis-childimg'>
											<div className='metalmorphosis-childtextbg'>

												<div className='metalmorphosis-child1'>
													<div className='metalmorphosis-childtext'>
														<a href='#'><img src={heart}></img> 231</a>
														<p>100 BUSD</p>
													</div>
													<h3>METAL MORPHOSIS</h3>
													<div className='metalmorphosis-child1text'>
														<div className='metalmorphosis-p'>
															<p>Highest Bid</p>
															<p>Your Bid</p>
															<p>Ends In</p>
														</div>
														<div className='metalmorphosis-p'>
															<p>100.00 BUSD</p>
															<p>0.00 BUSD</p>
															<p>28d:19h:17m</p>
														</div>
													</div>
												</div>
											</div>
										</div>
									</div>
								</div>
								<div className='metalmorphosis-bg'>
									<div className='metalmorphosis-img'>
										<div className='metalmorphosis-childimg'>
											<div className='metalmorphosis-childtextbg'>

												<div className='metalmorphosis-child1'>
													<div className='metalmorphosis-childtext'>
														<a href='#'><img src={heart}></img> 231</a>
														<p>100 BUSD</p>
													</div>
													<h3>METAL MORPHOSIS</h3>
													<div className='metalmorphosis-child1text'>
														<div className='metalmorphosis-p'>
															<p>Highest Bid</p>
															<p>Your Bid</p>
															<p>Ends In</p>
														</div>
														<div className='metalmorphosis-p'>
															<p>100.00 BUSD</p>
															<p>0.00 BUSD</p>
															<p>28d:19h:17m</p>
														</div>
													</div>
												</div>
											</div>
										</div>
									</div>
								</div>
								<div className='metalmorphosis-bg'>
									<div className='metalmorphosis-img'>
										<div className='metalmorphosis-childimg'>
											<div className='metalmorphosis-childtextbg'>

												<div className='metalmorphosis-child1'>
													<div className='metalmorphosis-childtext'>
														<a href='#'><img src={heart}></img> 231</a>
														<p>100 BUSD</p>
													</div>
													<h3>METAL MORPHOSIS</h3>
													<div className='metalmorphosis-child1text'>
														<div className='metalmorphosis-p'>
															<p>Highest Bid</p>
															<p>Your Bid</p>
															<p>Ends In</p>
														</div>
														<div className='metalmorphosis-p'>
															<p>100.00 BUSD</p>
															<p>0.00 BUSD</p>
															<p>28d:19h:17m</p>
														</div>
													</div>
												</div>
											</div>
										</div>
									</div>
								</div>
							</div>
							<div className='metalmorphosis-body'>
								<div className='metalmorphosis-bg'>
									<div className='metalmorphosis-img'>
										<div className='metalmorphosis-childimg'>
											<div className='metalmorphosis-childtextbg'>

												<div className='metalmorphosis-child1'>
													<div className='metalmorphosis-childtext'>
														<a href='#'><img src={heart}></img> 231</a>
														<p>100 BUSD</p>
													</div>
													<h3>METAL MORPHOSIS</h3>
													<div className='metalmorphosis-child1text'>
														<div className='metalmorphosis-p'>
															<p>Highest Bid</p>
															<p>Your Bid</p>
															<p>Ends In</p>
														</div>
														<div className='metalmorphosis-p'>
															<p>100.00 BUSD</p>
															<p>0.00 BUSD</p>
															<p>28d:19h:17m</p>
														</div>
													</div>
												</div>
											</div>
										</div>
									</div>
								</div>

								<div className='metalmorphosis-bg'>
									<div className='metalmorphosis-img'>
										<div className='metalmorphosis-childimg'>
											<div className='metalmorphosis-childtextbg'>

												<div className='metalmorphosis-child1'>
													<div className='metalmorphosis-childtext'>
														<a href='#'><img src={heart}></img> 231</a>
														<p>100 BUSD</p>
													</div>
													<h3>METAL MORPHOSIS</h3>
													<div className='metalmorphosis-child1text'>
														<div className='metalmorphosis-p'>
															<p>Highest Bid</p>
															<p>Your Bid</p>
															<p>Ends In</p>
														</div>
														<div className='metalmorphosis-p'>
															<p>100.00 BUSD</p>
															<p>0.00 BUSD</p>
															<p>28d:19h:17m</p>
														</div>
													</div>
												</div>
											</div>
										</div>
									</div>
								</div>
								<div className='metalmorphosis-bg'>
									<div className='metalmorphosis-img'>
										<div className='metalmorphosis-childimg'>
											<div className='metalmorphosis-childtextbg'>

												<div className='metalmorphosis-child1'>
													<div className='metalmorphosis-childtext'>
														<a href='#'><img src={heart}></img> 231</a>
														<p>100 BUSD</p>
													</div>
													<h3>METAL MORPHOSIS</h3>
													<div className='metalmorphosis-child1text'>
														<div className='metalmorphosis-p'>
															<p>Highest Bid</p>
															<p>Your Bid</p>
															<p>Ends In</p>
														</div>
														<div className='metalmorphosis-p'>
															<p>100.00 BUSD</p>
															<p>0.00 BUSD</p>
															<p>28d:19h:17m</p>
														</div>
													</div>
												</div>
											</div>
										</div>
									</div>
								</div>
								<div className='metalmorphosis-bg'>
									<div className='metalmorphosis-img'>
										<div className='metalmorphosis-childimg'>
											<div className='metalmorphosis-childtextbg'>

												<div className='metalmorphosis-child1'>
													<div className='metalmorphosis-childtext'>
														<a href='#'><img src={heart}></img> 231</a>
														<p>100 BUSD</p>
													</div>
													<h3>METAL MORPHOSIS</h3>
													<div className='metalmorphosis-child1text'>
														<div className='metalmorphosis-p'>
															<p>Highest Bid</p>
															<p>Your Bid</p>
															<p>Ends In</p>
														</div>
														<div className='metalmorphosis-p'>
															<p>100.00 BUSD</p>
															<p>0.00 BUSD</p>
															<p>28d:19h:17m</p>
														</div>
													</div>
												</div>
											</div>
										</div>
									</div>
								</div>
							</div>
							<div className='metalmorphosis-body'>
								<div className='metalmorphosis-bg'>
									<div className='metalmorphosis-img'>
										<div className='metalmorphosis-childimg'>
											<div className='metalmorphosis-childtextbg'>

												<div className='metalmorphosis-child1'>
													<div className='metalmorphosis-childtext'>
														<a href='#'><img src={heart}></img> 231</a>
														<p>100 BUSD</p>
													</div>
													<h3>METAL MORPHOSIS</h3>
													<div className='metalmorphosis-child1text'>
														<div className='metalmorphosis-p'>
															<p>Highest Bid</p>
															<p>Your Bid</p>
															<p>Ends In</p>
														</div>
														<div className='metalmorphosis-p'>
															<p>100.00 BUSD</p>
															<p>0.00 BUSD</p>
															<p>28d:19h:17m</p>
														</div>
													</div>
												</div>
											</div>
										</div>
									</div>
								</div>

								<div className='metalmorphosis-bg'>
									<div className='metalmorphosis-img'>
										<div className='metalmorphosis-childimg'>
											<div className='metalmorphosis-childtextbg'>

												<div className='metalmorphosis-child1'>
													<div className='metalmorphosis-childtext'>
														<a href='#'><img src={heart}></img> 231</a>
														<p>100 BUSD</p>
													</div>
													<h3>METAL MORPHOSIS</h3>
													<div className='metalmorphosis-child1text'>
														<div className='metalmorphosis-p'>
															<p>Highest Bid</p>
															<p>Your Bid</p>
															<p>Ends In</p>
														</div>
														<div className='metalmorphosis-p'>
															<p>100.00 BUSD</p>
															<p>0.00 BUSD</p>
															<p>28d:19h:17m</p>
														</div>
													</div>
												</div>
											</div>
										</div>
									</div>
								</div>
								<div className='metalmorphosis-bg'>
									<div className='metalmorphosis-img'>
										<div className='metalmorphosis-childimg'>
											<div className='metalmorphosis-childtextbg'>

												<div className='metalmorphosis-child1'>
													<div className='metalmorphosis-childtext'>
														<a href='#'><img src={heart}></img> 231</a>
														<p>100 BUSD</p>
													</div>
													<h3>METAL MORPHOSIS</h3>
													<div className='metalmorphosis-child1text'>
														<div className='metalmorphosis-p'>
															<p>Highest Bid</p>
															<p>Your Bid</p>
															<p>Ends In</p>
														</div>
														<div className='metalmorphosis-p'>
															<p>100.00 BUSD</p>
															<p>0.00 BUSD</p>
															<p>28d:19h:17m</p>
														</div>
													</div>
												</div>
											</div>
										</div>
									</div>
								</div>
								<div className='metalmorphosis-bg'>
									<div className='metalmorphosis-img'>
										<div className='metalmorphosis-childimg'>
											<div className='metalmorphosis-childtextbg'>

												<div className='metalmorphosis-child1'>
													<div className='metalmorphosis-childtext'>
														<a href='#'><img src={heart}></img> 231</a>
														<p>100 BUSD</p>
													</div>
													<h3>METAL MORPHOSIS</h3>
													<div className='metalmorphosis-child1text'>
														<div className='metalmorphosis-p'>
															<p>Highest Bid</p>
															<p>Your Bid</p>
															<p>Ends In</p>
														</div>
														<div className='metalmorphosis-p'>
															<p>100.00 BUSD</p>
															<p>0.00 BUSD</p>
															<p>28d:19h:17m</p>
														</div>
													</div>
												</div>
											</div>
										</div>
									</div>
								</div>
							</div>
						</div>
						<div className=''>
							<div className='container'>
								<div className='nftmarketplace-child1'>
									<div className='stakenft-text'>
										<h3>NFT MARKETPLACE</h3>
									</div>
									<div className='btntext-body'>
										<div className='collection-btn1'>
											<a href='#'>TOTAL VALUE LOCKED</a>
										</div>
										<div className='create22-nftbg'>
											<a href='#'><p className='createbtn-nftbtn22'>$23483.10</p></a>
										</div>
									</div>
								</div>
								<div className='stakenft-text'>
									<p>Stake and earn new  tokens. You can unstake at any time but there 2% unstake fee for all pools<br></br>
										Rewards are celculated per block.</p>
								</div>
								<div className='undead-bg'>
									<div className='undeadtext-bodyflex'>
										<div className='undeadtext-flex'>
											<div className='undeadicom-img'>
												<img src={icon333}></img>
											</div>
											<div className='undead-text'>
												<p>UNDEAD</p>
											</div>
										</div>
										<div className='deposit-textbtn'>
											<a href='#'><p className='deposit-nftbtn'>DEPOSIT</p></a>
										</div>
									</div>

								</div>
								<div className='undead-bg'>
									<div className='undeadtext-bodyflex'>
										<div className='undeadtext-flex'>
											<div className='undeadicom-img'>
												<img src={icon333}></img>
											</div>
											<div className='undead-text'>
												<p>UNDEAD</p>
											</div>
										</div>
										<div className='deposit-textbtn'>
											<a href='#'><p className='deposit-nftbtn'>DEPOSIT</p></a>
										</div>
									</div>

								</div>
								<div className='undead-bg'>
									<div className='undeadtext-bodyflex'>
										<div className='undeadtext-flex'>
											<div className='undeadicom-img'>
												<img src={icon333}></img>
											</div>
											<div className='undead-text'>
												<p>UNDEAD</p>
											</div>
										</div>
										<div className='deposit-textbtn'>
											<a href='#'><p className='deposit-nftbtn'>DEPOSIT</p></a>
										</div>
									</div>

								</div>
								<div className='undead-bg'>
									<div className='undeadtext-bodyflex'>
										<div className='undeadtext-flex'>
											<div className='undeadicom-img'>
												<img src={icon333}></img>
											</div>
											<div className='undead-text'>
												<p>UNDEAD</p>
											</div>
										</div>
										<div className='deposit-textbtn'>
											<a href='#'><p className='deposit-nftbtn'>DEPOSIT</p></a>
										</div>
									</div>

								</div>
							</div>

						</div>

					</div>
					<div className='footericon22'>
						<div className='copy-icon-wrp1'>
							<div className='icon-ing1'>
								<div className='icon-child1'>
									<a href='#'><img src={socialcharacter}></img></a>
								</div>
								<div className='icon-child1'>
									<a href='#'><img src={twitter}></img></a>
								</div>
								<div className='icon-child1'>
									<a href='#'><img src={telegram}></img></a>
								</div>
								<div className='icon-child1'>
									<a href='#'><img src={Subtraction}></img></a>
								</div>
							</div>
							<div className='copy-text1'>
								<p>© 2022 Arcane. All rights reserved.</p>
							</div>
						</div>

					</div>

				</div>

				{/* <Footer /> */}
			</div >

		);
	}

}
export default Home;