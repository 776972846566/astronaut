import React, { Component, useEffect } from 'react';
import { Button, Modal, ModalHeader, ModalBody, Row } from 'reactstrap';

import { ToastContainer } from 'react-toastify';
import '../css/style.css'
import '../css/responsive.css'
// import '../css/navbar.css'
import $ from "jquery";
import {Link, Router} from 'react-router-dom';
import logo from '../images/logo.png';
import burger from '../images/burger.png';
import connect from '../images/connect.png';
import gcircle from '../images/gcircle.png';
import crosss from '../images/crosss.png';
import copyaddress from '../images/copyaddress.png';
import menu from '../images/menu.png';



const Header = () => {
 
 

		return(
       <div>
         <div className='header-main-wrap'>
           <div className='container-fluid'>
              <div className='row'>
                <div className='col-lg-3'>
                  <div className='logo'>
                    <a className='#'><img src={logo}></img></a>
                  </div>
                </div>
                <div className='col-lg-1'></div>
                <div className='col-lg-8'>
                  <div className='navigate-wrap'>
                    <ul className='navigate'>
                    <li><a href="/#banner-sec">NFT ECOSYSTEM</a></li>
                      <li><a href="/#start-section">Games</a></li>
                      <li><a href="/#collect-section">spell inventory</a></li>
                      <li><a href="/#collect-section">IDO</a></li>
                      <li><div className='addbut'><p>325.68 MERLIN</p></div></li>
                      <li><div className='copyaddress-wrap'>
                            <div className='copyaddress-left'>
                              <p>0x0Eef...b994</p>
                            </div>
                            <div className='copyaddress-right'>
                              <a href='#'><img src={copyaddress}></img></a>
                            </div>
                          </div>
                      </li>
                      <li><a href="/#collect-section"><img src={menu}></img></a></li>
                    </ul>
                  </div>
                </div>
              </div>
           </div>
         </div>
       </div>
		);
 
}


export default Header;

